# Readme

To open this web app, just simply click the index.html, then you can see this page on your screen.
![image](images/1.png)
And then you can click one the left button, and it will bring you to this nav menu.
![image2](images/3.png)
Then you can enjoy this webapp.
Of course you can have [this](https://vision-173113.firebaseapp.com) online version which is the one I have on the google firebase server.
